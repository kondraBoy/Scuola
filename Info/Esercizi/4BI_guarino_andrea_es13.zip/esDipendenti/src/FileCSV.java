public interface FileCSV {
    public void fromCsv(String csv);
    public String toCsv();
}
